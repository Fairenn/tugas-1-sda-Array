import java.util.ArrayList;

public class soal4 {
    public static void main(String[] args) {
        ArrayList<String> nama = new ArrayList<String>();
        nama.add("l");
        nama.add("l");
        nama.add("a");
        nama.add("h");

        //indexOf()
        System.out.println(nama.indexOf("a"));
        System.out.println(nama.indexOf("c"));
        System.out.println(nama.indexOf("q"));
    
    }
    
}
