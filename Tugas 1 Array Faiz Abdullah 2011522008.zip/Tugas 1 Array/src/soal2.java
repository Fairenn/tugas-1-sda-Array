public class soal2 {
    public static void main(String[] args) {
        String nama[] = {"l","l","a","h"};

        //size()
        System.out.println("Size Array = "+nama.length);
    }
    
}
